public class Main {

    public class Coche{
        int npuertas;

        public void incrementarPuertas(){
            this.npuertas = npuertas++;
        }

        public Coche() {}
    }

    public int sumarNumeros(int a, int b, int c){
        int resultado = a + b + c;
        return resultado;
    }

    public void main(String[] args){
        int suma = sumarNumeros(1,2,3);
        Coche car = new Coche();
        car.incrementarPuertas();
        System.out.println(car.npuertas);
    }
}
